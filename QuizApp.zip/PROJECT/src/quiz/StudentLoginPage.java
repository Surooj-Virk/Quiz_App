package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentLoginPage {
    private JFrame loginFrame;
    private JPanel loginPanel;
    private JTextField usernameField;
    private JTextField quizIDField;

    public StudentLoginPage() {
        loginFrame = new JFrame("Student Login");
        loginPanel = new JPanel();
        usernameField = new JTextField(20);
        quizIDField = new JTextField(10);
        JLabel usernameLabel = new JLabel("Enter your username:");
        JLabel quizIDLabel = new JLabel("Enter Quiz ID:");
        JButton loginButton = new JButton("Login");

        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(quizIDLabel);
        loginPanel.add(quizIDField);
        loginPanel.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String studentUsername = usernameField.getText();
                String quizID = quizIDField.getText();

                if (!studentUsername.isEmpty() && !quizID.isEmpty()) {
                    if (isValidStudent(studentUsername, quizID)) {
                        openTestPage(studentUsername, quizID);
                    } else {
                        JOptionPane.showMessageDialog(loginFrame, "Invalid student username");
                    }
                }
            }
        });

        // Add a window listener to handle the window closing event
        loginFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                returnToRoleSelectionPage();
            }
        });

        loginFrame.add(loginPanel, BorderLayout.CENTER);
        loginFrame.setSize(300, 200);
        loginFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        loginFrame.setVisible(true);
    }

    private boolean isValidStudent(String username, String quizID) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            try (PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM student WHERE username = ? AND quizID = ?")) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, quizID);
                ResultSet resultSet = preparedStatement.executeQuery();
                return resultSet.next();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private void openTestPage(String studentUsername, String quizID) {
        loginFrame.dispose();
        SwingUtilities.invokeLater(() -> {
            new Test(studentUsername, quizID).setVisible(true);
        });
    }

    private void returnToRoleSelectionPage() {
        RoleSelectionPage roleSelectionPage = new RoleSelectionPage();
        roleSelectionPage.setVisible(true);
        loginFrame.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentLoginPage();
        });
    }
}
