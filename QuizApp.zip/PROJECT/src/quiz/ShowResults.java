package quiz;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ShowResults extends JFrame {

    private static final long serialVersionUID = 1L;

    public ShowResults(String quizID) {
        setBounds(100, 100, 800, 500);
        setTitle("Quiz Results");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Add a window listener to handle the window closing event
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //returnToRoleSelectionPage();
            dispose();
            }
        });

        // Get data from the database based on the provided quizID
        Object[][] data = getDataFromDatabase(quizID);
        String[] columns = {"Quiz ID", "Total Score", "Total Students"};

        // Create a JTable with the data and columns
        JTable table = new JTable(data, columns);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane);
    }
    private Object[][] getDataFromDatabase(String quizID) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            // Create user_response table if not exist
            createUserResponseTable(connection);

            String query = "SELECT DISTINCT ur.Username, COUNT(ur.Username) AS TotalStudents, SUM(CASE WHEN q.Answer = ur.selected_option THEN 1 ELSE 0 END) AS Score " +
                    "FROM user_response ur " +
                    "JOIN questions q ON ur.question_id = q.QuestionID " +
                    "WHERE q.QuizID = ? " +
                    "GROUP BY ur.Username";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
                preparedStatement.setString(1, quizID);
                ResultSet resultSet = preparedStatement.executeQuery();

                // Get the number of rows in the result set
                resultSet.last();
                int rowCount = resultSet.getRow();
                resultSet.beforeFirst();

                // Initialize the data array
                Object[][] data = new Object[rowCount][3];

                // Populate the data array
                int row = 0;
                while (resultSet.next()) {
                    String username = resultSet.getString("Username");
                    int totalScore = resultSet.getInt("Score");
                    int totalStudents = resultSet.getInt("TotalStudents");

                    data[row][0] = username;
                    data[row][1] = totalScore;
                    data[row][2] = totalStudents;

                    row++;
                }

                return data;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return new Object[0][0]; // Return an empty array if an exception occurs
    }

private void createUserResponseTable(Connection connection) {
    try (Statement statement = connection.createStatement()) {
        // SQL query to create user_response table if not exists
        String createTableQuery = "CREATE TABLE IF NOT EXISTS user_response (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "username VARCHAR(255)," +
                "question_id INT," +
                "selected_option VARCHAR(255)," +
                "FOREIGN KEY (question_id) REFERENCES questions(QuestionID)" +
                ")";

        statement.executeUpdate(createTableQuery);
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}