package quiz;



import java.sql.SQLException;

public class Main {
    public static void main(String s[]) throws SQLException  
    {  
           System.out.println("connection"+ ConnectionProvider.getConnection());
           System.out.println("hello");

        new RoleSelectionPage();
        
    }  
}