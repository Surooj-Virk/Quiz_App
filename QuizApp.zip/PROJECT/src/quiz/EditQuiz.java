package quiz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

public class EditQuiz extends JInternalFrame {
    private static final long serialVersionUID = 1L;
    NumberOfQuestions numberOfQuestions = new NumberOfQuestions();
    int numberofQuestion = numberOfQuestions.getCount();

    JPanel panel = new JPanel();
    JLabel quizIdLabel = new JLabel("Quiz ID:");
    JLabel questionIdLabel = new JLabel("Question ID:");
    JLabel questionLabel = new JLabel("Question");
    JLabel options1 = new JLabel("Option1");
    JLabel options2 = new JLabel("Option2");
    JLabel options3 = new JLabel("Option3");
    JLabel options4 = new JLabel("Option4");
    JLabel answer = new JLabel("Answer");

    JTextField tf_quizID = new JTextField();
    JTextField tf_questionID = new JTextField();
    JTextField tf_question = new JTextField();
    JTextField tf_option1 = new JTextField();
    JTextField tf_option2 = new JTextField();
    JTextField tf_option3 = new JTextField();
    JTextField tf_option4 = new JTextField();
    JTextField tf_answer = new JTextField();

    JButton btn_search_quiz = new JButton("Search Quiz");
    JButton btn_search_question = new JButton("Search Question");
    JButton btn_edit_question = new JButton("Update Question");
    JButton btn_delete_question = new JButton("Delete");

    EditQuiz() {
        quizIdLabel.setBounds(10, 10, 80, 30);
        tf_quizID.setBounds(100, 10, 80, 30);
        btn_search_quiz.setBounds(200, 10, 120, 30);

        questionIdLabel.setBounds(10, 50, 80, 30);
        tf_questionID.setBounds(100, 50, 80, 30);
        btn_search_question.setBounds(200, 50, 120, 30);

        questionLabel.setBounds(10, 90, 80, 30);
        options1.setBounds(10, 130, 80, 30);
        options2.setBounds(10, 170, 80, 30);
        options3.setBounds(10, 210, 80, 30);
        options4.setBounds(10, 250, 80, 30);
        answer.setBounds(10, 290, 80, 30);

        tf_question.setBounds(100, 90, 200, 30);
        tf_option1.setBounds(100, 130, 200, 30);
        tf_option2.setBounds(100, 170, 200, 30);
        tf_option3.setBounds(100, 210, 200, 30);
        tf_option4.setBounds(100, 250, 200, 30);
        tf_answer.setBounds(100, 290, 200, 30);

        btn_edit_question.setBounds(40, 330, 150, 30);
        btn_delete_question.setBounds(200, 330, 120, 30);

        panel.add(quizIdLabel);
        panel.add(tf_quizID);
        panel.add(btn_search_quiz);

        panel.add(questionIdLabel);
        panel.add(tf_questionID);
        panel.add(btn_search_question);

        panel.add(questionLabel);
        panel.add(options1);
        panel.add(options2);
        panel.add(options3);
        panel.add(options4);
        panel.add(answer);
        panel.add(tf_question);
        panel.add(tf_option1);
        panel.add(tf_option2);
        panel.add(tf_option3);
        panel.add(tf_option4);
        panel.add(tf_answer);

        panel.add(btn_edit_question);
        panel.add(btn_delete_question);

        btn_search_quiz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add logic to search for Quiz based on tf_quizID.getText()
                // Display Quiz details or handle accordingly
            }
        });

        btn_search_question.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                EditQuestion();
            }
        });

        btn_edit_question.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UpdateQuestion();
            }
        });

        btn_delete_question.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteQuestion();
            }
        });

        panel.setLayout(null);

        add(panel);
        setSize(400, 400);
        setClosable(true);
        setVisible(true);
        setTitle("Update Questions");
    }

    private void EditQuestion() {
        String QuestionID = tf_questionID.getText();
        Connection con = ConnectionProvider.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement("select * from questions where QuestionID = ?");
            ps.setString(1, QuestionID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tf_quizID.setText(rs.getString("QuizID"));
                tf_question.setText(rs.getString("Name"));
                tf_option1.setText(rs.getString("Option1"));
                tf_option2.setText(rs.getString("Option2"));
                tf_option3.setText(rs.getString("Option3"));
                tf_option4.setText(rs.getString("Option4"));
                tf_answer.setText(rs.getString("Answer"));
            } else {
                JOptionPane.showMessageDialog(null, "Question ID is wrong");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void UpdateQuestion() {
        int x = 0;
        String Question = tf_question.getText();
        String option1 = tf_option1.getText();
        String option2 = tf_option2.getText();
        String option3 = tf_option3.getText();
        String option4 = tf_option4.getText();
        String answer = tf_answer.getText();
        String QuizID = tf_quizID.getText();
        String QuestionID = tf_questionID.getText();

        Connection con = ConnectionProvider.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement("UPDATE questions SET Name=?, Option1=?, Option2=?, Option3=?, Option4=?, Answer=? WHERE QuestionID=? AND QuizID=?");
            ps.setString(1, Question);
            ps.setString(2, option1);
            ps.setString(3, option2);
            ps.setString(4, option3);
            ps.setString(5, option4);
            ps.setString(6, answer);
            ps.setString(7, QuestionID);
            ps.setString(8, QuizID);

            ps.executeUpdate();
            x++;
            if (x > 0) {
                JOptionPane.showMessageDialog(btn_edit_question, "Question Updated Successfully");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void DeleteQuestion() {
        Connection con = ConnectionProvider.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM questions WHERE QuestionID=? AND QuizID=?");
            ps.setString(1, tf_questionID.getText());
            ps.setString(2, tf_quizID.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Deleted Successfully");
            resetFields();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void resetFields() {
        tf_quizID.setText("");
        tf_questionID.setText("");
        tf_question.setText("");
        tf_option1.setText("");
        tf_option2.setText("");
        tf_option3.setText("");
        tf_option4.setText("");
        tf_answer.setText("");
    }

    public static void main(String s[]) {
        new EditQuiz();
    }
}
