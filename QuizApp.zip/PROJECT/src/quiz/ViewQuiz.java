package quiz;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewQuiz extends JInternalFrame {
    private static final long serialVersionUID = 1L;
    NumberOfQuestions numberOfQuestions = new NumberOfQuestions();
    public int numberofQuestion = numberOfQuestions.getCount();

    String Questions[][] = new String[numberofQuestion][6]; // Increased the array size to accommodate question IDs
    String Answers[][] = new String[numberofQuestion][1];
    JLabel[][] options;

    public ViewQuiz(String quizIdParameter) {
        options = new JLabel[numberofQuestion][4];

        Connection con = ConnectionProvider.getConnection();
        int i = 0;
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM questions WHERE QuizID = ?");
            ps.setString(1, quizIdParameter);
            ResultSet rs = ps.executeQuery();

            // Clear the existing labels
            clearLabels();

            // Populate the questions and answers arrays with the retrieved data
            while (rs.next()) {
                Questions[i][0] = rs.getString(1); // Assuming question ID is in the first column
                Questions[i][1] = rs.getString(2);
                Questions[i][2] = rs.getString(3);
                Questions[i][3] = rs.getString(4);
                Questions[i][4] = rs.getString(5);
                Questions[i][5] = rs.getString(6);
                Answers[i][0] = rs.getString(7);

                // Create labels for options
                options[i][0] = new JLabel(Questions[i][2]);
                options[i][1] = new JLabel(Questions[i][3]);
                options[i][2] = new JLabel(Questions[i][4]);
                options[i][3] = new JLabel(Questions[i][5]);

                // Add labels to the panel with horizontal layout
                add(new JLabel("Question ID: " + Questions[i][0])); // Add question ID label
                add(new JLabel("Question: " + Questions[i][1])); // Add question label
                for (int j = 0; j < 4; j++) {
                    add(options[i][j]);
                }
                i++;
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }

        // Use BoxLayout for a vertical layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        setClosable(true);
        setVisible(true);
        setTitle("Questions for Quiz ID: " + quizIdParameter);
    }

    private void clearLabels() {
        getContentPane().removeAll();
        revalidate();
        repaint();
    }
}
