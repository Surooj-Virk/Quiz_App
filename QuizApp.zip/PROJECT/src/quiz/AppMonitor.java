package quiz;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JOptionPane;

public class AppMonitor {
    public static void main(String[] args) {
        try {
            if (checkForOpenChromeProcesses()) {
                // Show a warning dialog
                String message = "Warning: Quiz App detected open Chrome processes!";
                JOptionPane.showMessageDialog(null, message, "Warning", JOptionPane.WARNING_MESSAGE);
                // Add your custom action or warning message here
                // For example, you might want to terminate the application at this point
                return;
            } else {
                System.out.println("No issue detected. Quiz App is ready.");
                // Add the new function call to start the Quiz app
                new RoleSelectionPage();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            // Handle exceptions based on your project's requirements
        }
    }

    private static boolean checkForOpenChromeProcesses() throws IOException, InterruptedException {
        // Execute the shell script to check for open Chrome processes
        ProcessBuilder processBuilder = new ProcessBuilder("D:\\Downloads\\PROJECT\\check_chrome_process.sh");
        processBuilder.redirectErrorStream(true); // Redirect error stream to output stream
        Process process = processBuilder.start();

        // Read the script output
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }

        // Wait for the process to complete
        int exitCode = process.waitFor();

        // Return true if Chrome processes are detected, false otherwise
        return exitCode == 0;
    }
}
