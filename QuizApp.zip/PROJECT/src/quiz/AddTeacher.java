package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.regex.Pattern;

public class AddTeacher {
    private JFrame frame;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField phoneNumberField;
    private JPasswordField passwordField;
    private int teacherId;

    public void Teacher(int teacherId, String firstName, String lastName, String email) {
        this.teacherId = teacherId;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public AddTeacher() {
        frame = new JFrame("Add Teacher");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Add a window listener to handle the window closing event
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Handle the window closing event
                returnToRoleSelectionPage();
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel phoneNumberLabel = new JLabel("Phone Number:");
        JLabel passwordLabel = new JLabel("Password:");

        firstNameField = new JTextField();
        lastNameField = new JTextField();
        emailField = new JTextField();
        phoneNumberField = new JTextField();
        passwordField = new JPasswordField();

        JButton addButton = new JButton("Add Teacher");
        JButton addNewTeacherButton = new JButton("Add New Teacher");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTeacher();
            }
        });

        addNewTeacherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(phoneNumberLabel);
        panel.add(phoneNumberField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // Empty label as a placeholder for layout
        panel.add(addButton);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(addNewTeacherButton);

        frame.add(panel, BorderLayout.CENTER);

        frame.setSize(300, 250);
        frame.setVisible(true);
    }

    private boolean validateInputs(String firstName, String lastName, String email,
            String phoneNumber, String password) {
// Email validation using a simple regex (checks if it ends with "@gmail.com")
if (!Pattern.matches(".+@gmail\\.com", email)) {
JOptionPane.showMessageDialog(frame, "Invalid email format (must end with @gmail.com).", "Error", JOptionPane.ERROR_MESSAGE);
return false;
}

// Password strength validation
if (password.length() < 8 ||
!Pattern.compile("[A-Z]").matcher(password).find() ||
!Pattern.compile("[a-z]").matcher(password).find() ||
!Pattern.compile("[!@#$%^&*(),.?\":{}|<>]").matcher(password).find()) {
JOptionPane.showMessageDialog(frame, "Password must be at least 8 characters long " +
"and contain at least one uppercase letter, one lowercase letter, and one special character.", "Error", JOptionPane.ERROR_MESSAGE);
return false;
}

return !firstName.isEmpty() && !lastName.isEmpty() && !email.isEmpty() &&
!phoneNumber.isEmpty() && !password.isEmpty();
}

    private boolean addTeacher() {
        // Handle add teacher button click
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String phoneNumber = phoneNumberField.getText();
        String password = new String(passwordField.getPassword());

        if (validateInputs(firstName, lastName, email, phoneNumber, password)) {
            if (addTeacher(firstName, lastName, email, phoneNumber, password)) {
                JOptionPane.showMessageDialog(frame, "Teacher added successfully!");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to add teacher.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    
    private boolean addTeacher(String firstName, String lastName, String email,
                               String phoneNumber, String password) {
        // Add the teacher data to the teacher table in the database
        Connection con = ConnectionProvider.getConnection();

        try {
            // Hash the password using a secure hashing algorithm before inserting it
            String hashedPassword = hashPassword(password);

            // SQL query to insert data into the teacher table
            String sql = "INSERT INTO teacher (first_name, last_name, email, phone_number, password) " +
                    "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
                // Set values for the prepared statement
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, phoneNumber);
                preparedStatement.setString(5, hashedPassword);

                // Execute the query
                preparedStatement.executeUpdate();

                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String hashPassword(String password) {
        // Implement your password hashing logic here
        // For example, you can use libraries like BCrypt or other secure hashing algorithms
        return password;
    }

    private void returnToRoleSelectionPage() {
        // Implement the logic to return to the RoleSelectionPage
        // For example, you can create and show a new instance of the RoleSelectionPage
        RoleSelectionPage roleSelectionPage = new RoleSelectionPage();
        roleSelectionPage.setVisible(true);
        frame.dispose(); // Close the current frame
    }

    private void clearFields() {
        // Clear input fields for adding a new teacher
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        phoneNumberField.setText("");
        passwordField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddTeacher();
            }
        });
    }
}
