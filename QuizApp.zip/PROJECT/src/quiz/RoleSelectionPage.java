package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RoleSelectionPage extends JFrame {  // Extend JFrame
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JRadioButton studentRadioButton;
    private JRadioButton teacherRadioButton;
    private JRadioButton adminRadioButton;

    public RoleSelectionPage() {
        setTitle("Role Selection");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JLabel label = new JLabel("Select your role:");

        studentRadioButton = new JRadioButton("Student");
        teacherRadioButton = new JRadioButton("Teacher");
        adminRadioButton = new JRadioButton("Admin");

        ButtonGroup roleGroup = new ButtonGroup();
        roleGroup.add(studentRadioButton);
        roleGroup.add(teacherRadioButton);
        roleGroup.add(adminRadioButton);

        JButton continueButton = new JButton("Continue");
        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Check the selected role and take appropriate action
                if (studentRadioButton.isSelected()) {
                    // Handle student role
                    new StudentLoginPage();
                } else if (teacherRadioButton.isSelected()) {
                    // Handle teacher role
                    new Registration();
                } else if (adminRadioButton.isSelected()) {
                    // Handle admin role
                    new AdminLoginPage();
                } else {
                    // No role selected, display an error message
                    JOptionPane.showMessageDialog(RoleSelectionPage.this, "Please select your role.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Return without closing the frame if no role is selected
                }

                // Close the RoleSelectionPage after a role is selected
                dispose();
            }
        });

        panel.add(label);
        panel.add(studentRadioButton);
        panel.add(teacherRadioButton);
        panel.add(adminRadioButton);

        add(panel, BorderLayout.CENTER);
        add(continueButton, BorderLayout.SOUTH);

        setSize(300, 200);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RoleSelectionPage();
            }
        });
    }
}
