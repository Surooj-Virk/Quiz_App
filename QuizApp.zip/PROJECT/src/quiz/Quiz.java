package quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Quiz {
    private int quizID;

    public Quiz() {
        this.quizID = 0;
    }

    public int getQuizID() {
        return this.quizID;
    }

    public void connection(String quizName) {
        Connection con = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            con = ConnectionProvider.getConnection();

            String query = "SELECT QuizID FROM quiz WHERE Name = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, quizName);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                this.quizID = resultSet.getInt("QuizID");
            } else {
                System.out.println("Quiz not found: " + quizName);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's needs
        } finally {
            closeResources(resultSet, preparedStatement, con);
        }
    }

    // A method for closing ResultSet, PreparedStatement, and Connection
    private void closeResources(ResultSet resultSet, PreparedStatement preparedStatement, Connection connection) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's needs
        }
    }
}
