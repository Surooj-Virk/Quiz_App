package quiz;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AddStudent extends JFrame {

    private static final long serialVersionUID = 1L;
    private JButton assignStudentInfoButton;
    private JTextField numberOfStudentsField;
    private JTextField quizIDField; // Added JTextField for entering Quiz ID
    private List<String> studentIDs;
    private List<String> studentUsernames;
    private JPanel studentEntryPanel; // Move the panel to a class-level field
    private String quizID; // Added variable to store Quiz ID

    public AddStudent() {
        initializeUI();
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Assign Student Info");

        JPanel assignStudentInfoPanel = new JPanel(new FlowLayout());
        assignStudentInfoButton = new JButton("Assign Student Info");
        numberOfStudentsField = new JTextField(5);
        quizIDField = new JTextField(10); // Added JTextField for entering Quiz ID
        studentIDs = new ArrayList<>();
        studentUsernames = new ArrayList<>();
        assignStudentInfoPanel.add(new JLabel("Enter Quiz ID:")); // Changed label
        assignStudentInfoPanel.add(quizIDField); // Added field for entering Quiz ID
        assignStudentInfoPanel.add(new JLabel("Number of Students:"));
        assignStudentInfoPanel.add(numberOfStudentsField);
        assignStudentInfoPanel.add(assignStudentInfoButton);

        add(assignStudentInfoPanel, BorderLayout.CENTER);

        assignStudentInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showStudentPanel();
            }
        });

        setSize(400, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void showStudentPanel() {
        try {
            // Get Quiz ID
            quizID = quizIDField.getText();

            // Check if Quiz ID is empty
            if (quizID.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter Quiz ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int numberOfStudents = Integer.parseInt(numberOfStudentsField.getText());

            studentEntryPanel = new JPanel(new GridLayout(numberOfStudents, 3));

            // Clear the lists before adding new data
            studentIDs.clear();
            studentUsernames.clear();

            for (int i = 0; i < numberOfStudents; i++) {
                JTextField idField = new JTextField(10);
                JTextField usernameField = new JTextField(20);

                studentEntryPanel.add(new JLabel("Student " + (i + 1) + " ID:"));
                studentEntryPanel.add(idField);
                studentEntryPanel.add(new JLabel("Student " + (i + 1) + " Username:"));
                studentEntryPanel.add(usernameField);
            }

            int result = JOptionPane.showConfirmDialog(this, studentEntryPanel, "Assign Student IDs",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                for (int i = 0; i < numberOfStudents; i++) {
                    JTextField idField = (JTextField) studentEntryPanel.getComponent(i * 4 + 1); // Note the change in index
                    JTextField usernameField = (JTextField) studentEntryPanel.getComponent(i * 4 + 3); // Note the change in index

                    String id = idField.getText().substring(0, Math.min(idField.getText().length(), 10)); // Trim to 10 characters
                    String username = usernameField.getText();

                    System.out.println("Quiz ID: " + quizID + ", Student ID: " + id + ", Username: " + username);

                    if (!id.isEmpty() && !username.isEmpty()) {
                        studentIDs.add(id);
                        studentUsernames.add(username);
                    } else {
                        JOptionPane.showMessageDialog(this,
                                "Please enter both student ID and username for all students.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return; // Stop processing if any entry is invalid
                    }
                }

                // Save student data to the database
                saveStudentDataToDatabase();

                // After assigning all students, display a summary message
                JOptionPane.showMessageDialog(this, "Total Students Assigned: " + numberOfStudents
                        + "\nIDs and Usernames added to the list. Student data saved to the database.");

            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number of students.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveStudentDataToDatabase() {
        // Your existing code for saving data to the database
        // ...
        String jdbcUrl = "jdbc:mysql://localhost:3306/quiz";
        String username = "root";
        String password = "Mehran93me92";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            // Create the Student table if it doesn't exist
            createStudentTable(connection);

            // Check if the Quiz ID exists in the Quiz table
            if (!isQuizIdExists(connection, quizID)) {
                JOptionPane.showMessageDialog(this, "Quiz ID does not exist. Please enter a valid Quiz ID.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Insert student data into the Student table
            for (int i = 0; i < studentIDs.size(); i++) {
                String id = studentIDs.get(i);
                String username1 = studentUsernames.get(i);

                String sql = "INSERT INTO student (id, username, QuizID) VALUES (?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setString(1, id);
                    preparedStatement.setString(2, username1);
                    preparedStatement.setString(3, quizID);
                    preparedStatement.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving student data to the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createStudentTable(Connection connection) throws SQLException {
        // Your existing code for creating the student table
        // ...
        String createTableSQL = "CREATE TABLE IF NOT EXISTS student ("
                + "id VARCHAR(10) PRIMARY KEY,"
                + "username VARCHAR(255) NOT NULL,"
                + "QuizID VARCHAR(10) REFERENCES Quiz(QuizID))";

        try (Statement statement = connection.createStatement()) {
            statement.execute(createTableSQL);
        }
    }

    private boolean isQuizIdExists(Connection connection, String quizID) throws SQLException {
        String sql = "SELECT * FROM quiz WHERE QuizID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, quizID);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddStudent();
            }
        });
    }
}
