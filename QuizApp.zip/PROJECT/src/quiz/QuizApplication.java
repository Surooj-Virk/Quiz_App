package quiz;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class QuizApplication implements ActionListener {

    JFrame f;
    JPanel p, p1;
    CardLayout card;
    JDesktopPane desktop;
    Container c;
    JButton addQuiz = new JButton("Add Question");
    JButton updateQuiz = new JButton("Update Or Remove Question");
    JButton viewQuiz = new JButton("View Questions");
    JButton addStd = new JButton("Assign Students");
    JButton viewScore = new JButton("View Results");
    JButton exit = new JButton("Exit");
    JButton logout = new JButton("Logout");
    JPanel cardPanel; // Panel to hold different cards (subpanels)
    CardLayout cardLayout; // CardLayout for switching between cards

    QuizApplication() {
        f = new JFrame();
        p = new JPanel();
        p1 = new JPanel();
        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);

        p.add(addQuiz);
        p.add(updateQuiz);
        p.add(viewQuiz);
        p.add(addStd);
        p.add(viewScore);
        p.add(exit);
        p.add(logout);
        p.setLayout(new GridLayout(7, 1));

        f.add(p, BorderLayout.LINE_START);
        f.add(cardPanel, BorderLayout.CENTER);

        addQuiz.addActionListener(this);
        updateQuiz.addActionListener(this);
        viewQuiz.addActionListener(this);
        addStd.addActionListener(this);
        viewScore.addActionListener(this);
        exit.addActionListener(this);
        logout.addActionListener(this);

        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setSize(200, 200);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addQuiz) {
            AddQuiz addQuizPanel = new AddQuiz();
            cardPanel.add(addQuizPanel, "AddQuiz");
            cardLayout.show(cardPanel, "AddQuiz");
        }
        if (e.getSource() == updateQuiz) {
            EditQuiz editQuizPanel = new EditQuiz();
            cardPanel.add(editQuizPanel, "EditQuiz");
            cardLayout.show(cardPanel, "EditQuiz");
        }
        if (e.getSource() == viewQuiz) {
        	 SwingUtilities.invokeLater(() -> {
                 // Prompt the user for quiz ID
                 String quizId = JOptionPane.showInputDialog("Enter Quiz ID:");

                 if (quizId != null && !quizId.isEmpty()) {
                    // new ViewQuiz(quizId);
                  ViewQuiz viewQuizPanel = new ViewQuiz(quizId);
               cardPanel.add(viewQuizPanel, "ViewQuiz");
               cardLayout.show(cardPanel, "ViewQuiz");
                 } else {
                     JOptionPane.showMessageDialog(null, "Invalid Quiz ID. Please enter a valid ID.", "Error", JOptionPane.ERROR_MESSAGE);
                 }
        	//  String quizID = JOptionPane.showInputDialog("Enter Quiz ID:");
              //if (quizID != null && !quizID.isEmpty()) {
//            	 // ViewQuiz viewQuizPanel = new ViewQuiz(null);
//              	//cardPanel.add(viewQuizPanel, "ViewQuiz");
//              	//cardLayout.show(cardPanel, "ViewQuiz");
              //} else {
                //  JOptionPane.showMessageDialog(null, "Invalid Quiz ID. Exiting...");
              //}
        	 
        	 });
        	 }
        if (e.getSource() == addStd) {
          new AddStudent();
        }
        if (e.getSource() == viewScore) {
            String quizID = JOptionPane.showInputDialog("Enter Quiz ID:");
            if (quizID != null && !quizID.isEmpty()) {
                new ShowResults(quizID).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Quiz ID. Exiting...");
            }
        }

        if (e.getSource() == exit) {
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setVisible(false);
        }
        if (e.getSource() == logout) {
            f.setVisible(false);
            new Registration();
        }
    }

	

}
