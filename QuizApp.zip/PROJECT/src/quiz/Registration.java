package quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Registration {
    private JFrame frame;
    private JTextField emailField;
    private JPasswordField passwordField;

    public Registration() {
        frame = new JFrame("Teacher Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");

        emailField = new JTextField();
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle login button click
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (validateTeacherLogin(email, password)) {
                    JOptionPane.showMessageDialog(frame, "Login successful!");

                    // Close the current login frame
                    frame.dispose();

                    // Open the QuizApplication frame
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            new QuizApplication();
                        }
                    });
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid email or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // Empty label as a placeholder for layout
        panel.add(loginButton);

        frame.add(panel, BorderLayout.CENTER);

        frame.setSize(300, 150);
        frame.setVisible(true);
    }
    public class User {
        private String userID;

        public User(String userID) {
            this.userID = userID;
        }

        public String getUserID() {
            return userID;
        }
    }
    private boolean validateTeacherLogin(String email, String password) {
        // Validate the login credentials from the teacher table in the database
        Connection con = ConnectionProvider.getConnection();

        try {
            String hashedPassword = hashPassword(password);

            // SQL query to check if the email and hashed password match
            String sql = "SELECT * FROM teacher WHERE email = ? AND password = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, hashedPassword);

                ResultSet resultSet = preparedStatement.executeQuery();

                // If a row is found, the login is successful
                return resultSet.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String hashPassword(String password) {
        // Implement your password hashing logic here
        // For example, you can use libraries like BCrypt or other secure hashing algorithms
        return password;
    }

    
}
