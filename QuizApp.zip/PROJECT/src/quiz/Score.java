package quiz;import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Score extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private static String username;
    private static String quizID;
    private static int totalQuestions;
    private static String[] selectedAnswers;  // Store selected answers

    // Constructor to receive the name, score, and quiz ID
    Score(String username, String quizID, int correctAnswers, int totalQuestions) {
        Score.username = username;
        Score.quizID = quizID;
        Score.totalQuestions = totalQuestions;

        setBounds(600, 150, 750, 550);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel l2 = new JLabel("Thank you for Solving Quiz");
        l2.setBounds(45, 30, 700, 30);
        l2.setFont(new Font("RALEWAY", Font.PLAIN, 26));
        add(l2);

        JLabel l3 = new JLabel("Your Score is " + correctAnswers + "/" + totalQuestions);
        l3.setBounds(350, 200, 300, 30);
        l3.setFont(new Font("Jokerman", Font.PLAIN, 26));
        l3.setForeground(new Color(199, 21, 133));
        add(l3);

        JLabel label = new JLabel("This is the Score panel");
        add(label);

        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setBackground(Color.BLUE);
        playAgainButton.setForeground(Color.WHITE);
        playAgainButton.addActionListener(this);
        playAgainButton.setBounds(400, 270, 120, 30);
        add(playAgainButton);

        // Store results in the database
        storeResultsInDatabase();
    }

    // Additional Constructor to receive correctAnswers and totalQuestions from NumberOfQuestions
    Score(int correctAnswers, NumberOfQuestions numberOfQuestions) {
        Score.totalQuestions = numberOfQuestions.getCount();

        setBounds(600, 150, 750, 550);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel l2 = new JLabel("Thank you for Solving Quiz");
        l2.setBounds(45, 30, 700, 30);
        l2.setFont(new Font("RALEWAY", Font.PLAIN, 26));
        add(l2);

        JLabel l3 = new JLabel("Your Score is " + correctAnswers + "/" + totalQuestions);
        l3.setBounds(350, 200, 300, 30);
        l3.setFont(new Font("Jokerman", Font.PLAIN, 26));
        l3.setForeground(new Color(199, 21, 133));
        add(l3);

        JLabel label = new JLabel("This is the Score panel");
        add(label);

        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setBackground(Color.BLUE);
        playAgainButton.setForeground(Color.WHITE);
        playAgainButton.addActionListener(this);
        playAgainButton.setBounds(400, 270, 120, 30);
        add(playAgainButton);

        // Store results in the database
        storeResultsInDatabase();
    }

    // Method to set selected answers from the UI
    public static void setSelectedAnswers(String[] answers) {
        selectedAnswers = answers;
    }

    // Method to store results in the user_response table
    public static void storeResultsInDatabase() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            // Create the user_response table if it doesn't exist
            createTableIfNotExists(connection);

            String query = "INSERT INTO user_response (Username, QuizID, Answer, IsCorrect) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                // Fetch answers from questions table
                String fetchAnswersQuery = "SELECT Answer FROM questions WHERE QuizID = ?";
                try (PreparedStatement fetchAnswersStatement = connection.prepareStatement(fetchAnswersQuery)) {
                    fetchAnswersStatement.setString(1, quizID);
                    ResultSet resultSet = fetchAnswersStatement.executeQuery();

                    int questionNumber = 0;

                    while (resultSet.next() && questionNumber < totalQuestions) {
                        String correctAnswer = resultSet.getString("Answer");
                        String selectedAnswer = selectedAnswers[questionNumber];

                        // Check if the selected answer matches the correct answer (case-insensitive)
                        boolean isCorrect = correctAnswer.equalsIgnoreCase(selectedAnswer);

                        // Store results in the user_response table
                        preparedStatement.setString(1, username);
                        preparedStatement.setString(2, quizID);
                        preparedStatement.setString(3, selectedAnswer);
                        preparedStatement.setBoolean(4, isCorrect);

                        preparedStatement.executeUpdate();

                        questionNumber++;
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Method to create the user_response table if it doesn't exist
    private static void createTableIfNotExists(Connection connection) {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS user_response ("
                + "ID INT AUTO_INCREMENT PRIMARY KEY,"
                + "Username VARCHAR(255),"
                + "QuizID VARCHAR(255),"
                + "Answer VARCHAR(255),"
                + "IsCorrect BOOLEAN)";
        try (PreparedStatement createTableStatement = connection.prepareStatement(createTableQuery)) {
            createTableStatement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        this.setVisible(false);
        // Pass the username and quizID to the new Test instance to display a personalized message
        new Test(username, quizID).setVisible(true);
    }

    public static void main(String[] args) {
        // Sample usage: set selected answers and create Score instance
        String[] selectedAnswers = {"A", "B", "C", "D", "A"};
        setSelectedAnswers(selectedAnswers);
        new Score("SampleUser", "SampleQuizID", 3, 5).setVisible(true);
    }
}
