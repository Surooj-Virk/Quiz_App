package quiz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

// New interface for user options
interface UserOptionsInterface {
    void takeQuiz(String username, String quizID);
    void openQuizApplication();
}

public class UserProfile implements UserOptionsInterface {
    JFrame f;
    JPanel panel;
    QuizApplication quizApp;  // Reference to QuizApplication

    UserProfile(String username) {
        f = new JFrame();
        panel = new JPanel();
        JButton b5 = new JButton("Take Quiz");
        JButton b6 = new JButton("Open Quiz Application");

        panel.add(b5);
        panel.add(b6);

        f.add(panel, BorderLayout.CENTER);

        quizApp = new QuizApplication();  // Instantiate QuizApplication

        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String quizID = fetchQuizID(); // Fetch quizID from the database, replace it with the actual logic
                takeQuiz(username, quizID);
            }
        });

        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openQuizApplication();
            }
        });

        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setTitle("Welcome " + username);
        f.setSize(300, 300);
        f.setVisible(true);
    }

    // Implementation of UserOptionsInterface
    public void takeQuiz(String username, String quizID) {
        new Test(username, quizID);
        f.setVisible(false);
    }

    public void openQuizApplication() {
        quizApp.f.setVisible(true);
        f.setVisible(false);
    }

    // Method to fetch quizID from the database (replace with your database logic)
    private String fetchQuizID() {
        String quizID = ""; // Default value, replace it with a proper default or handle cases where no ID is found
        try (Connection connection = ConnectionProvider.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT QuizID FROM quiz WHERE conditions")) {
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                quizID = resultSet.getString("QuizID");
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle database exceptions properly
        }
        return quizID;
    }
}
