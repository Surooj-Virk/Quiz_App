package quiz;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AddQuiz extends JInternalFrame {
    private static final long serialVersionUID = 1L;
    NumberOfQuestions numberOfQuestions = new NumberOfQuestions();
    int i;
    int numberofQuestion = numberOfQuestions.getCount();

    JPanel panel = new JPanel();
    JLabel question = new JLabel("Question");
    JPanel[] quizes = new JPanel[10];
    JLabel[] questions = new JLabel[10];

    JLabel quizIdLabel = new JLabel("QuizID");
    JLabel nameLabel = new JLabel("Quiz Name");
    JLabel options1 = new JLabel("Option1");
    JLabel options2 = new JLabel("Option2");
    JLabel options3 = new JLabel("Option3");
    JLabel options4 = new JLabel("Option4");
    JLabel answer = new JLabel("Answer");

    JTextField tf_quizID = new JTextField();
    JTextField tf_quizName = new JTextField();
    JTextField tf_question = new JTextField();
    JTextField tf_option1 = new JTextField();
    JTextField tf_option2 = new JTextField();
    JTextField tf_option3 = new JTextField();
    JTextField tf_option4 = new JTextField();
    JTextField tf_answer = new JTextField();

    JButton btn_add_question = new JButton("Add Question");
    JButton btn_add_quiz = new JButton("Add Quiz");
    String Quiz[] = new String[10];
    JComboBox<Object> cb_quiz;

    Quiz quiz = new Quiz();

    public AddQuiz() {
        AddQuizes();
        cb_quiz = new JComboBox<Object>(Quiz);

        question.setBounds(10, 10, 80, 30);
        options1.setBounds(10, 80, 80, 30);
        options2.setBounds(10, 110, 80, 30);
        options3.setBounds(10, 150, 80, 30);
        options4.setBounds(10, 190, 80, 30);
        answer.setBounds(10, 230, 80, 30);

        quizIdLabel.setBounds(40, 270, 100, 30);
        nameLabel.setBounds(40, 310, 100, 30);
        tf_quizID.setBounds(160, 270, 100, 30);
        tf_quizName.setBounds(160, 310, 100, 30);

        tf_question.setBounds(100, 10, 200, 30);
        tf_option1.setBounds(100, 80, 80, 30);
        tf_option2.setBounds(100, 110, 80, 30);
        tf_option3.setBounds(100, 150, 80, 30);
        tf_option4.setBounds(100, 190, 80, 30);
        tf_answer.setBounds(100, 230, 80, 30);

        cb_quiz.setBounds(40, 270, 100, 40);
        btn_add_question.setBounds(40, 360, 120, 30);
        btn_add_quiz.setBounds(180, 360, 120, 30);

        panel.add(question);
        panel.add(options1);
        panel.add(options2);
        panel.add(options3);
        panel.add(options4);
        panel.add(answer);

        panel.add(quizIdLabel);
        panel.add(nameLabel);
        panel.add(tf_quizID);
        panel.add(tf_quizName);

        panel.add(tf_question);
        panel.add(tf_option1);
        panel.add(tf_option2);
        panel.add(tf_option3);
        panel.add(tf_option4);
        panel.add(tf_answer);

        panel.add(btn_add_question);
        panel.add(btn_add_quiz);

        for (int i = 0; i < 10; i++) {
            panel.add(questions[i] = new JLabel(Quiz[i]));
            panel.add(quizes[i] = new JPanel());
        }

        btn_add_question.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddQuestion();
                resetFields();
            }
        });

        btn_add_quiz.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddQuizDetails();
            }
        });

        panel.setLayout(null);

        add(panel);
        setSize(600, 600);

        setClosable(true);
        setVisible(true);
        setTitle("Add New Question");
        pack();
    }

    private void AddQuestion() {
        int x = 0;
        String Question = tf_question.getText();
        String Option1 = tf_option1.getText();
        String Option2 = tf_option2.getText();
        String Option3 = tf_option3.getText();
        String Option4 = tf_option4.getText();
        String Answer = tf_answer.getText();
        String QuizID = tf_quizID.getText();
        Connection con = ConnectionProvider.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement(
                    "insert into questions (Name, Option1, Option2, Option3, Option4, Answer, QuizID) values(?,?,?,?,?,?,?)");
            ps.setString(1, Question);
            ps.setString(2, Option1);
            ps.setString(3, Option2);
            ps.setString(4, Option3);
            ps.setString(5, Option4);
            ps.setString(6, Answer);
            ps.setString(7, QuizID);

            ps.executeUpdate();
            x++;
            if (x > 0) {
                JOptionPane.showMessageDialog(btn_add_question, "Question Saved Successfully");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void AddQuizDetails() {
        String QuizID = tf_quizID.getText();
        String Name = tf_quizName.getText();

        Connection con = ConnectionProvider.getConnection();

        try {
            PreparedStatement checkStatement = con.prepareStatement("SELECT * FROM quiz WHERE QuizID = ? ");
            checkStatement.setString(1, QuizID);
    
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                JOptionPane.showMessageDialog(btn_add_quiz, "Quiz with the same ID already exists");
            } else {
                PreparedStatement insertStatement = con.prepareStatement("INSERT INTO quiz (QuizID, Name) VALUES (?, ?)");
                insertStatement.setString(1, QuizID);
                insertStatement.setString(2, Name);
        

                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(btn_add_quiz, "Quiz Details Saved Successfully");
                    
                    // Refresh the quiz names after adding a new quiz
                  //  refreshQuizNames();
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void AddQuizes() {
        Connection con = ConnectionProvider.getConnection();
        try {
            // Clear existing quiz names
            for (int i = 0; i < 10; i++) {
                Quiz[i] = null;
            }

            // Fetch and store the updated quiz names
            PreparedStatement ps = con.prepareStatement("SELECT * FROM quiz WHERE Name = ?");
            //ps.setString(1, subjectTaught);

            ResultSet rs = ps.executeQuery();
            int index = 0;
            while (rs.next() && index < 10) {
                Quiz[index++] = rs.getString("Name");
                System.out.println(Quiz[index - 1]);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }


    private void resetFields() {
        tf_quizID.setText("");
        tf_quizName.setText("");
        tf_question.setText("");
        tf_option1.setText("");
        tf_option2.setText("");
        tf_option3.setText("");
        tf_option4.setText("");
        tf_answer.setText("");
    }
}
