package quiz;

//UPDATE THE CODE WHEN WE CLOSE THE ADMINLOGINPAGE WINDOW IT WILL NOT CLOSE THE ROLE SELECTION PAGE 

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminLoginPage {
    private JFrame frame;
    private JTextField emailField;
    private JPasswordField passwordField;

    public AdminLoginPage() {
        frame = new JFrame("Admin Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");

        emailField = new JTextField();
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle login button click
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (validateLogin(email, password)) {
                    JOptionPane.showMessageDialog(frame, "Login successful!");
                    // Add code to open the main admin window or perform other actions
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid email or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // Empty label as a placeholder for layout
        panel.add(loginButton);

        frame.add(panel, BorderLayout.CENTER);

        frame.setSize(300, 150);
        frame.setVisible(true);
    }

    private boolean validateLogin(String email, String password) {
        // Validate the login credentials from the admin table in the database
        Connection con = ConnectionProvider.getConnection();

        try {
            String hashedPassword = hashPassword(password);

            // SQL query to check if the email and hashed password match
            String sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, hashedPassword);

                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    // Open the AddTeacherPage
                    openAddTeacherPage();
                    return true;
                } else {
                    return false;
                }
                
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    private void openAddTeacherPage() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Close the current login frame
                frame.dispose();
                
                // Open the AddTeacherPage
                new AddTeacher();
            }
        });
    }
    private String hashPassword(String password) {
        // Implement your password hashing logic here
        // For example, you can use libraries like BCrypt or other secure hashing algorithms
        return password;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminLoginPage();
            }
        });
    }
}

