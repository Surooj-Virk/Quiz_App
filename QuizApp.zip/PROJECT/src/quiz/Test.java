package quiz;
import java.sql.Statement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Test extends JFrame {

    private static final long serialVersionUID = 1L;
    private ArrayList<JPanel> questionPanels;
    private ArrayList<JLabel> questionLabels;
    private ArrayList<JComboBox<String>> answerComboBoxes;

    private String studentID; // Assuming studentID is an integer
    private String quizID;

    public Test(String studentUsername, String quizID) {
        this.studentID = getStudentID(studentUsername); // Retrieve student ID based on username
        this.quizID = quizID;

        setTitle("Quiz App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        fetchQuestionsFromDatabase(quizID);
        pack();
        setVisible(true);
    }

    private String getStudentID(String studentUsername) {
        String id = null ; // Default value if not found

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            String query = "SELECT id FROM student WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, studentUsername);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    id = resultSet.getString("id");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
		return id;
    }

    private void initUI() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        questionPanels = new ArrayList<>();
        questionLabels = new ArrayList<>();
        answerComboBoxes = new ArrayList<>();

        JButton submitButton = new JButton("Submit Quiz");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSubmit();
            }
        });

        mainPanel.add(submitButton);

        add(mainPanel);
    }

    private void fetchQuestionsFromDatabase(String quizID) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            String query = "SELECT * FROM questions WHERE QuizID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, quizID);

                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String questionText = resultSet.getString("Name");
                    String[] options = {
                            resultSet.getString("Option1"),
                            resultSet.getString("Option2"),
                            resultSet.getString("Option3"),
                            resultSet.getString("Option4")
                    };

                    JPanel questionPanel = new JPanel();
                    questionPanel.setLayout(new GridLayout(2, 1));

                    JLabel questionLabel = new JLabel(questionText);
                    JComboBox<String> answerComboBox = new JComboBox<>(options);

                    questionLabels.add(questionLabel);
                    answerComboBoxes.add(answerComboBox);

                    questionPanel.add(questionLabel);
                    questionPanel.add(answerComboBox);

                    questionPanels.add(questionPanel);
                    ((JPanel) getContentPane().getComponent(0)).add(questionPanel);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void handleSubmit() {
        for (int i = 0; i < answerComboBoxes.size(); i++) {
            int questionID = getQuestionID();

            String selectedAnswer = (String) answerComboBoxes.get(i).getSelectedItem();

            storeUserResponseInDatabase(studentID, quizID, questionID, selectedAnswer);
        }

        dispose();
    }

 
    private int getQuestionID() {
        int questionID = -1; // Default value if not found

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            String query = "SELECT QuestionID FROM questions WHERE QuizID = ? ";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, quizID);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    questionID = resultSet.getInt("QuestionID");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return questionID;
    }

    private void storeUserResponseInDatabase(String studentID, String quizID, int questionID, String selectedAnswer) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Mehran93me92")) {
            // Create user_response table if not exists
            createUserResponseTable(connection);

            String query = "INSERT INTO user_response (username, quiz_id, question_id, selected_option) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, studentID);
                preparedStatement.setString(2, quizID);
                preparedStatement.setInt(3, questionID);
                preparedStatement.setString(4, selectedAnswer);

                preparedStatement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void createUserResponseTable(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            // SQL query to create user_response table if not exists
            String createTableQuery = "CREATE TABLE IF NOT EXISTS user_response (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "username VARCHAR(255)," +
                    "quiz_id VARCHAR(255)," +
                    "question_id INT," +
                    "selected_option VARCHAR(255)," +
                    "FOREIGN KEY (question_id) REFERENCES questions(QuestionID)" +
                    ")";

            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Pass studentUsername and quizID to the constructor
                new Test("SampleUser", "SampleQuizID").setVisible(true);
            }
        });
    }
}
