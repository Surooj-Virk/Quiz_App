package quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NumberOfQuestions {
    private int count;

    public int getCount() {
        return count;
    }

    public NumberOfQuestions() {
        Connection con = ConnectionProvider.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT Count(*) FROM questions");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static void main(String args[]) {
        // Example: Create an instance of NumberOfQuestions
        NumberOfQuestions numberOfQuestions = new NumberOfQuestions();
        int count = numberOfQuestions.getCount();
        System.out.println("Count: " + count);
    }
}
