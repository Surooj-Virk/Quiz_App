package quiz;

public class index {

}
