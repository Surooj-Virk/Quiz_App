# Check for open Chrome processes
$chromeProcesses = Get-Process -Name "chrome" -ErrorAction SilentlyContinue

if ($chromeProcesses) {
    exit 0  # Chrome processes detected
} else {
    exit 1  # No Chrome processes detected
}

